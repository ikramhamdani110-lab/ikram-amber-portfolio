'use client'

import { motion } from 'framer-motion'
import { Award, ArrowUpRight } from 'lucide-react'
import type { Certification } from '@/lib/db'
import { SectionLabel } from '@/components/section-label'

interface Props {
  certifications: Certification[]
  num?: string
}

export function Certifications({ certifications, num = '04' }: Props) {
  // Only display visible certifications
  const visibleCerts = certifications.filter((c) => c.visible !== false)

  if (visibleCerts.length === 0) {
    return null
  }

  return (
    <div>
      <SectionLabel num={num} label="Certifications" />

      <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
        <h2 className="font-serif text-5xl font-light leading-[0.95] tracking-tight sm:text-6xl">
          Validated <span className="text-accent italic">expertise.</span>
        </h2>
        <p className="max-w-xs leading-relaxed text-muted-foreground">
          Certificates and credentials I have earned through coursework and examinations.
        </p>
      </div>

      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {visibleCerts.map((cert, i) => (
          <motion.div
            key={cert.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="group flex flex-col rounded-3xl border border-border bg-card/50 p-7 transition-colors hover:border-accent"
          >
            <div className="flex items-start justify-between">
              {cert.image ? (
                <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-white to-[#ffeaf3] shadow-md p-2 ring-1 ring-black/5">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={cert.image}
                    alt={`${cert.name} logo`}
                    width={40}
                    height={40}
                    className="size-10 object-contain"
                    crossOrigin="anonymous"
                  />
                </div>
              ) : (
                <div className="flex size-14 items-center justify-center rounded-2xl border border-border bg-card text-accent">
                  <Award className="size-6" />
                </div>
              )}

              {cert.credentialUrl && (
                <a
                  href={cert.credentialUrl}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={`View credential for ${cert.name}`}
                  className="rounded-full border border-border p-2.5 text-muted-foreground transition-colors hover:border-accent hover:text-accent"
                >
                  <ArrowUpRight className="size-4" />
                </a>
              )}
            </div>

            <h3 className="mt-6 font-serif text-xl font-medium tracking-tight leading-tight group-hover:text-accent transition-colors">
              {cert.name}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground font-serif italic">
              {cert.organization}
            </p>

            <div className="mt-4 flex flex-col gap-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground/80">
              <span>Issued: {cert.date}</span>
              {cert.credentialId && (
                <span className="truncate">ID: {cert.credentialId}</span>
              )}
            </div>

            {cert.description && (
              <p className="mt-4 border-t border-border/50 pt-4 text-xs leading-relaxed text-muted-foreground">
                {cert.description}
              </p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  )
}

