'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import type { SectionId } from '@/lib/data'
import type { DbSchema } from '@/lib/db'
import { SectionLabel } from '@/components/section-label'
import { cn } from '@/lib/utils'

interface Props {
  data: DbSchema['journey']
  linkedinUrl: string
  num?: string
}

export function Journey({ data, linkedinUrl, num = '05' }: Props) {
  const [active, setActive] = useState(0)
  
  const stages = data?.stages || []
  const stage = stages[active]
  const title = data?.title || 'Learning. Building. Growing.'

  // Render title with custom accent styling
  const renderTitle = () => {
    if (title.includes('Growing.')) {
      const parts = title.split('Growing.')
      return (
        <>
          {parts[0]}
          <span className="text-accent italic">Growing.</span>
          {parts[1]}
        </>
      )
    }
    const lastWordIndex = title.lastIndexOf(' ')
    if (lastWordIndex !== -1) {
      return (
        <>
          {title.substring(0, lastWordIndex)}
          <span className="text-accent italic"> {title.substring(lastWordIndex + 1)}</span>
        </>
      )
    }
    return title
  }

  if (stages.length === 0) {
    return null
  }

  // Handle out of index active item
  const currentActiveIndex = active >= stages.length ? 0 : active
  const activeStage = stages[currentActiveIndex]

  return (
    <div>
      <SectionLabel num={num} label="Journey" />

      <h2 className="font-serif text-5xl font-light leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl">
        {renderTitle()}
      </h2>

      {/* Stepper */}
      <div className="relative mt-14">
        <div className="absolute left-0 right-0 top-5 hidden h-px bg-border md:block" />
        <ol className="grid gap-6 md:grid-cols-5 md:gap-0" style={{ gridTemplateColumns: `repeat(${stages.length}, minmax(0, 1fr))` }}>
          {stages.map((s, i) => {
            const isActive = i === currentActiveIndex
            return (
              <li key={s.num} className="relative flex items-center gap-4 md:flex-col md:items-start md:gap-3">
                <button
                  onClick={() => setActive(i)}
                  className={cn(
                    'relative z-10 flex size-10 shrink-0 items-center justify-center rounded-full border font-mono text-xs transition-colors',
                    isActive
                      ? 'border-accent bg-accent-soft text-[#201319]'
                      : 'border-border bg-card text-muted-foreground hover:border-accent',
                  )}
                  aria-label={`${s.num} ${s.short}`}
                >
                  {s.num}
                </button>
                <button
                  onClick={() => setActive(i)}
                  className={cn(
                    'text-left font-serif text-lg transition-colors',
                    isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {s.short}
                </button>
              </li>
            )
          })}
        </ol>
      </div>

      {/* Detail card */}
      {activeStage && (
        <div className="relative mt-10 min-h-[220px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeStage.num}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.35 }}
              className="grid gap-6 rounded-3xl border border-border bg-gradient-to-br from-card/60 to-accent/5 p-8 sm:p-10 md:grid-cols-2 md:gap-12"
            >
              <div>
                <div className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  {activeStage.stage}
                </div>
                <h3 className="font-serif text-3xl sm:text-4xl">{activeStage.title}</h3>
              </div>
              <div className="flex flex-col justify-center gap-6">
                <p className="leading-relaxed text-muted-foreground">{activeStage.body}</p>
                <div className="flex flex-wrap gap-2">
                  {(activeStage.tags || []).map((tag) => (
                    <span key={tag} className="rounded-full border border-border px-4 py-1.5 text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      )}

      {/* CTA */}
      <div className="mt-12 flex flex-col items-start justify-between gap-6 border-t border-border pt-8 sm:flex-row sm:items-center">
        <p className="font-serif text-2xl sm:text-3xl">{data?.ctaTitle || 'Want to see more of my journey?'}</p>
        <a
          href={linkedinUrl || '#'}
          target="_blank"
          rel="noreferrer"
          className="group flex items-center gap-2 rounded-full bg-accent-soft px-6 py-3 text-sm font-medium text-[#201319] transition-transform hover:-translate-y-0.5"
        >
          {data?.ctaButtonText || 'Visit my LinkedIn'}
          <ArrowUpRight className="size-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </a>
      </div>
    </div>
  )
}
