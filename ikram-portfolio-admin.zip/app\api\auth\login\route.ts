import { NextResponse } from 'next/server'
import { setSessionCookie } from '@/lib/auth'

export async function POST(req: Request) {
  try {
    const { password } = await req.json()
    const expectedPassword = process.env.ADMIN_PASSWORD || 'admin123'
    
    if (password === expectedPassword) {
      await setSessionCookie('admin')
      return NextResponse.json({ success: true })
    }
    
    return NextResponse.json({ error: 'Invalid password' }, { status: 401 })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

