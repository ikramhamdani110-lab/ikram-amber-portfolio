import fs from 'fs'
import path from 'path'

// Define DB Types
export interface Skill {
  name: string
  note: string
  icon: string
}

export interface SkillGroup {
  num: string
  title: string
  skills: Skill[]
}

export interface JourneyStage {
  num: string
  short: string
  stage: string
  title: string
  body: string
  tags: string[]
}

export interface Certification {
  id: string
  name: string
  organization: string
  date: string
  credentialId?: string
  credentialUrl?: string
  image?: string
  description?: string
  visible: boolean
  order: number
}

export interface PortfolioUpdate {
  id: string
  title: string
  description: string
  date: string
  image?: string
  visible: boolean
  category: 'certification' | 'skill' | 'achievement' | 'experience' | 'update'
}

export interface DbSchema {
  hero: {
    hello: string
    name: string
    title: string
    bio: string
    location: string
    creativeTechnologist: string
    codeWindowFilename: string
    codeWindowCaption: string
    codeLines: { n: number; code: string }[]
    floaters: { icon: string; className: string; delay: string }[]
  }
  about: {
    title: string
    bio: string
    currently: string
    location: string
    focus: string[]
  }
  skills: {
    title: string
    description: string
    dbTextBadge: string
    aboutSkills: Skill[]
    groups: SkillGroup[]
  }
  journey: {
    title: string
    stages: JourneyStage[]
    ctaTitle: string
    ctaButtonText: string
  }
  socials: {
    github: string
    linkedin: string
    email: string
    fiverr?: string
  }
  siteSettings: {
    metaTitle: string
    metaDescription: string
    wordmark: string
    copyright: string
  }
  certifications: Certification[]
  updates: PortfolioUpdate[]
}

const DB_PATH = path.join(process.cwd(), 'data', 'db.json')

const D = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons'

const DEFAULT_DATA: DbSchema = {
  hero: {
    hello: "Hello, I'm",
    name: "IKRAM",
    title: "Information Science Student & Web Developer",
    bio: "I love turning ideas into digital experiences while exploring software, web technologies, databases, and information systems.",
    location: "Chlef · Algeria",
    creativeTechnologist: "Creative Technologist",
    codeWindowFilename: "ikram.js",
    codeWindowCaption: "built with curiosity",
    codeLines: [
      { n: 1, code: 'const ikram = {' },
      { n: 2, code: '  learns: "technology",' },
      { n: 3, code: '  builds: "web experiences",' },
      { n: 4, code: '  goal: "keep growing"' },
      { n: 5, code: '};' },
    ],
    floaters: [
      { icon: `${D}/python/python-original.svg`, className: 'left-2 top-10 sm:-left-6', delay: '0s' },
      { icon: `${D}/github/github-original.svg`, className: 'left-6 bottom-16 sm:left-0', delay: '1.5s' },
      { icon: `${D}/javascript/javascript-original.svg`, className: 'right-4 top-16 sm:-right-4', delay: '0.8s' },
      { icon: `${D}/css3/css3-original.svg`, className: 'bottom-14 right-6 sm:-right-2', delay: '2.2s' },
    ]
  },
  about: {
    title: "Curious by nature. Always learning.",
    bio: "I'm an Information Science student interested in software development, web technologies, databases, and information systems. I enjoy learning through experimentation and building practical things that turn ideas into working digital experiences.",
    currently: "Learning → Building → Experimenting",
    location: "Chlef, Algeria",
    focus: ['Web', 'Software', 'Databases']
  },
  skills: {
    title: "My digital toolbox.",
    description: "A growing ecosystem of languages and tools I use to learn, build and experiment. Hover a badge to see what it means to me.",
    dbTextBadge: "Database Design",
    aboutSkills: [
      { name: 'PYTHON', note: 'Scripting · Data · Automation', icon: `${D}/python/python-original.svg` },
      { name: 'MYSQL', note: 'Queries & relations', icon: `${D}/mysql/mysql-original.svg` },
      { name: 'HTML5', note: 'Semantic structure', icon: `${D}/html5/html5-original.svg` },
      { name: 'GIT', note: 'Version control', icon: `${D}/git/git-original.svg` },
    ],
    groups: [
      {
        num: '01',
        title: 'Programming',
        skills: [
          { name: 'C', note: 'Fundamentals · Memory · Logic', icon: `${D}/c/c-original.svg` },
          { name: 'PYTHON', note: 'Scripting · Data · Automation', icon: `${D}/python/python-original.svg` },
          { name: 'JAVA', note: 'OOP · Structured programs', icon: `${D}/java/java-original.svg` },
        ],
      },
      {
        num: '02',
        title: 'Web',
        skills: [
          { name: 'HTML5', note: 'Semantic structure', icon: `${D}/html5/html5-original.svg` },
          { name: 'CSS3', note: 'Layout · Motion · Design', icon: `${D}/css3/css3-original.svg` },
          { name: 'JAVASCRIPT', note: 'Interactivity & logic', icon: `${D}/javascript/javascript-original.svg` },
          { name: 'PHP', note: 'Server-side scripting', icon: `${D}/php/php-original.svg` },
        ],
      },
      {
        num: '03',
        title: 'Databases',
        skills: [
          { name: 'MYSQL', note: 'Queries & relations', icon: `${D}/mysql/mysql-original.svg` },
          { name: 'MARIADB', note: 'Open-source database', icon: `${D}/mariadb/mariadb-original.svg` },
        ],
      },
      {
        num: '04',
        title: 'Tools',
        skills: [
          { name: 'GIT', note: 'Version control', icon: `${D}/git/git-original.svg` },
          { name: 'GITHUB', note: 'Hosting & collaboration', icon: `${D}/github/github-original.svg` },
          { name: 'VS CODE', note: 'My daily editor', icon: `${D}/vscode/vscode-original.svg` },
          { name: 'XAMPP', note: 'Local server stack', icon: `${D}/xampp/xampp-original.svg` },
          { name: 'CODE::BLOCKS', note: 'C/C++ IDE', icon: `${D}/codeblocks/codeblocks-original.svg` },
        ],
      },
    ]
  },
  journey: {
    title: "Learning. Building. Growing.",
    ctaTitle: "Want to see more of my journey?",
    ctaButtonText: "Visit my LinkedIn",
    stages: [
      {
        num: '01',
        short: 'University',
        stage: 'STAGE 01',
        title: 'Information Science',
        body: 'Licence 2 — studying information systems, system modeling and the foundations that connect data, people and software.',
        tags: ['Information Systems', 'System Modeling'],
      },
      {
        num: '02',
        short: 'Programming',
        stage: 'STAGE 02',
        title: 'Foundations of code',
        body: 'Learning to think in logic — algorithms and data structures with C, Python and Java.',
        tags: ['Algorithms', 'Data Structures'],
      },
      {
        num: '03',
        short: 'Web Development',
        stage: 'STAGE 03',
        title: 'Building for the browser',
        body: 'Turning static pages into interactive experiences with HTML, CSS, JavaScript and PHP.',
        tags: ['HTML · CSS · JS', 'PHP'],
      },
      {
        num: '04',
        short: 'Databases',
        stage: 'STAGE 04',
        title: 'Structuring information',
        body: 'Designing and querying relational databases with MySQL and MariaDB.',
        tags: ['Database Design', 'SQL'],
      },
      {
        num: '05',
        short: 'Exploring',
        stage: 'STAGE 05',
        title: 'Always curious',
        body: 'Experimenting with new tools and ideas, and growing a little every single day.',
        tags: ['New tools', 'Side experiments'],
      },
    ]
  },
  socials: {
    github: 'https://github.com/ikramhamdani110-lab',
    linkedin: 'https://www.linkedin.com/in/REPLACE-WITH-YOUR-LINKEDIN',
    email: 'your.email@example.com',
  },
  siteSettings: {
    metaTitle: 'Ikram Hamdani | Information Science Student & Web Developer',
    metaDescription: 'I love turning ideas into digital experiences while exploring software, web technologies, databases, and information systems.',
    wordmark: 'IKRAM',
    copyright: '© 2026 Ikram Hamdani'
  },
  certifications: [],
  updates: []
}

export function readDb(): DbSchema {
  try {
    if (!fs.existsSync(DB_PATH)) {
      const dir = path.dirname(DB_PATH)
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
      }
      fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DATA, null, 2), 'utf-8')
      return DEFAULT_DATA
    }
    const content = fs.readFileSync(DB_PATH, 'utf-8')
    return JSON.parse(content) as DbSchema
  } catch (error) {
    console.error('Error reading DB:', error)
    return DEFAULT_DATA
  }
}

export function writeDb(data: DbSchema): boolean {
  try {
    const dir = path.dirname(DB_PATH)
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8')
    return true
  } catch (error) {
    console.error('Error writing DB:', error)
    return false
  }
}

