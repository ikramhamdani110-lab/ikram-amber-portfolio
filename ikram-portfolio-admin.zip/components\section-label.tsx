export function SectionLabel({ num, label }: { num: string; label: string }) {
  return (
    <div className="mb-10 flex items-center gap-4 font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
      <span className="h-px w-10 bg-muted-foreground/50" />
      {num} — {label}
    </div>
  )
}
