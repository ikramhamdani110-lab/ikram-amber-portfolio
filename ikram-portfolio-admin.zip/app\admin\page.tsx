'use client'

import { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import {
  Lock,
  Plus,
  Trash2,
  Edit,
  Save,
  ArrowUp,
  ArrowDown,
  Check,
  LogOut,
  Globe,
  Award,
  BookOpen,
  Briefcase,
  User,
  Settings,
  Bell,
  Upload,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  RefreshCw,
  FolderPlus,
  Code
} from 'lucide-react'
import type { DbSchema, Certification, PortfolioUpdate, Skill, SkillGroup, JourneyStage } from '@/lib/db'

export default function AdminPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [activeTab, setActiveTab] = useState<
    'overview' | 'profile' | 'skills' | 'journey' | 'certifications' | 'socials' | 'updates' | 'settings'
  >('overview')

  // Db State
  const [db, setDb] = useState<DbSchema | null>(null)
  const [loadingDb, setLoadingDb] = useState(false)
  const [saveStatus, setSaveStatus] = useState<string>('')

  // Check auth
  useEffect(() => {
    async function checkAuth() {
      try {
        const res = await fetch('/api/auth/check')
        const json = await res.json()
        setIsAuthenticated(json.authenticated)
        if (json.authenticated) {
          loadPortfolioData()
        }
      } catch (err) {
        setIsAuthenticated(false)
      }
    }
    checkAuth()
  }, [])

  // Load db data
  async function loadPortfolioData() {
    setLoadingDb(true)
    try {
      const res = await fetch('/api/portfolio')
      if (res.ok) {
        const data = await res.json()
        setDb(data)
      }
    } catch (err) {
      console.error('Failed to load portfolio data', err)
    } finally {
      setLoadingDb(false)
    }
  }

  // Handle login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      })
      if (res.ok) {
        setIsAuthenticated(true)
        loadPortfolioData()
      } else {
        const err = await res.json()
        setLoginError(err.error || 'Invalid credentials')
      }
    } catch (err) {
      setLoginError('Server connection error')
    }
  }

  // Handle logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setIsAuthenticated(false)
      setDb(null)
      setPassword('')
    } catch (err) {
      console.error('Logout error', err)
    }
  }

  // Generic Save Helper
  const saveSectionData = async (section: string, payload: any) => {
    setSaveStatus('saving')
    try {
      const res = await fetch(`/api/admin/${section}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (res.ok) {
        setSaveStatus('success')
        setTimeout(() => setSaveStatus(''), 2000)
        // Refresh local DB
        loadPortfolioData()
      } else {
        setSaveStatus('error')
      }
    } catch (err) {
      setSaveStatus('error')
    }
  }

  // Image Upload helper
  const uploadImage = async (file: File): Promise<string> => {
    const formData = new FormData()
    formData.append('file', file)
    const res = await fetch('/api/admin/upload', {
      method: 'POST',
      body: formData,
    })
    if (!res.ok) throw new Error('Upload failed')
    const json = await res.json()
    return json.path
  }

  // Render Login Screen
  if (isAuthenticated === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#141013] text-foreground font-mono text-xs">
        Checking secure session...
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#141013] px-4">
        <div className="w-full max-w-sm rounded-3xl border border-border bg-[#0e0b0d] p-8 shadow-2xl">
          <div className="flex flex-col items-center text-center">
            <div className="flex size-14 items-center justify-center rounded-2xl bg-accent-soft text-[#201319] mb-4">
              <Lock className="size-6" />
            </div>
            <h1 className="font-serif text-3xl font-light">Admin Access</h1>
            <p className="mt-2 text-xs font-mono text-muted-foreground uppercase tracking-widest">
              Ikram Hamdani Portfolio
            </p>
          </div>

          <form onSubmit={handleLogin} className="mt-8 space-y-4">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">
                Security Password
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-2xl border border-border bg-card p-4 text-sm focus:border-accent outline-none transition-colors text-foreground"
              />
            </div>

            {loginError && (
              <div className="flex items-center gap-2 rounded-xl bg-red-950/30 border border-red-900/50 p-3 text-xs text-red-400">
                <AlertCircle className="size-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full rounded-full bg-accent-soft py-4 text-sm font-medium text-[#201319] transition-transform hover:-translate-y-0.5"
            >
              Sign In
            </button>
          </form>
        </div>
      </div>
    )
  }

  if (loadingDb || !db) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#141013] text-foreground font-mono text-xs">
        Loading CMS configurations...
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#141013] text-foreground flex flex-col md:flex-row">
      {/* Sidebar Panel */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-border bg-[#0e0b0d] p-6 flex flex-col justify-between shrink-0">
        <div>
          <div className="font-serif text-2xl font-medium tracking-tight mb-8">
            IKRAM<span className="text-accent">.</span> Dashboard
          </div>

          <nav className="space-y-1">
            {[
              { id: 'overview', label: 'Overview', icon: Globe },
              { id: 'profile', label: 'Profile & Hero', icon: User },
              { id: 'skills', label: 'Skills', icon: RefreshCw },
              { id: 'certifications', label: 'Certifications', icon: Award },
              { id: 'journey', label: 'Journey Stages', icon: BookOpen },
              { id: 'socials', label: 'Social Links', icon: Globe },
              { id: 'updates', label: 'Updates Feed', icon: Bell },
              { id: 'settings', label: 'Site Settings', icon: Settings },
            ].map((tab) => {
              const Icon = tab.icon
              const isActive = activeTab === tab.id
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-xs font-mono uppercase tracking-wider transition-colors ${
                    isActive
                      ? 'bg-accent-soft text-[#201319]'
                      : 'text-muted-foreground hover:bg-card hover:text-foreground'
                  }`}
                >
                  <Icon className="size-4 shrink-0" />
                  {tab.label}
                </button>
              )
            })}
          </nav>
        </div>

        <div className="mt-8 pt-4 border-t border-border/40">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 rounded-2xl px-4 py-3 text-left text-xs font-mono uppercase tracking-wider text-red-400 hover:bg-red-950/20 transition-colors"
          >
            <LogOut className="size-4 shrink-0" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto max-w-5xl mx-auto w-full">
        {/* Header bar */}
        <div className="flex items-center justify-between border-b border-border/40 pb-5 mb-8">
          <div>
            <h2 className="font-serif text-3xl font-light uppercase tracking-tight">
              {activeTab.replace('-', ' ')}
            </h2>
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mt-1">
              CMS Panel / {activeTab}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {saveStatus === 'saving' && (
              <span className="text-xs font-mono text-accent animate-pulse">Saving changes...</span>
            )}
            {saveStatus === 'success' && (
              <span className="text-xs font-mono text-green-400 flex items-center gap-1">
                <Check className="size-3.5" /> Saved!
              </span>
            )}
            {saveStatus === 'error' && (
              <span className="text-xs font-mono text-red-400 flex items-center gap-1">
                <AlertCircle className="size-3.5" /> Save failed
              </span>
            )}
            <a
              href="/"
              target="_blank"
              className="rounded-full border border-border px-4 py-2 text-[10px] font-mono uppercase tracking-wider hover:border-accent hover:text-accent transition-colors"
            >
              View Site
            </a>
          </div>
        </div>

        {/* CMS TAB CONTENTS */}
        {activeTab === 'overview' && (
          <OverviewTab db={db} setActiveTab={setActiveTab} />
        )}
        {activeTab === 'profile' && (
          <ProfileTab db={db} save={saveSectionData} uploadImage={uploadImage} />
        )}
        {activeTab === 'skills' && (
          <SkillsTab db={db} save={saveSectionData} />
        )}
        {activeTab === 'journey' && (
          <JourneyTab db={db} save={saveSectionData} />
        )}
        {activeTab === 'certifications' && (
          <CertificationsTab db={db} save={saveSectionData} uploadImage={uploadImage} />
        )}
        {activeTab === 'socials' && (
          <SocialsTab db={db} save={saveSectionData} />
        )}
        {activeTab === 'updates' && (
          <UpdatesTab db={db} save={saveSectionData} uploadImage={uploadImage} />
        )}
        {activeTab === 'settings' && (
          <SettingsTab db={db} save={saveSectionData} />
        )}
      </main>
    </div>
  )
}

// ----------------------------------------------------
// 1. OVERVIEW TAB
// ----------------------------------------------------
function OverviewTab({ db, setActiveTab }: { db: DbSchema; setActiveTab: any }) {
  const visibleCerts = db.certifications?.filter((c) => c.visible !== false) || []
  const visibleUpdates = db.updates?.filter((u) => u.visible !== false) || []

  return (
    <div className="space-y-8">
      {/* Quick stats grid */}
      <div className="grid gap-5 sm:grid-cols-4">
        {[
          { label: 'Skill Badges', count: db.skills?.aboutSkills?.length + (db.skills?.groups?.reduce((acc, curr) => acc + curr.skills.length, 0) || 0), tab: 'skills' },
          { label: 'Certifications', count: db.certifications?.length || 0, tab: 'certifications' },
          { label: 'Journey Stages', count: db.journey?.stages?.length || 0, tab: 'journey' },
          { label: 'Updates Posted', count: db.updates?.length || 0, tab: 'updates' },
        ].map((stat, i) => (
          <button
            key={i}
            onClick={() => setActiveTab(stat.tab)}
            className="text-left rounded-3xl border border-border bg-[#0e0b0d] p-6 hover:border-accent transition-colors"
          >
            <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              {stat.label}
            </div>
            <div className="font-serif text-4xl font-light mt-3">{stat.count}</div>
          </button>
        ))}
      </div>

      {/* Quick actions & status */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card/40 p-7">
          <h3 className="font-serif text-xl font-light mb-4">Quick Content Creator</h3>
          <div className="grid gap-3">
            <button
              onClick={() => setActiveTab('certifications')}
              className="flex items-center justify-between rounded-2xl border border-border bg-[#0e0b0d] p-4 text-xs font-mono uppercase tracking-wider hover:border-accent text-left"
            >
              Add New Certification
              <Plus className="size-4 text-accent" />
            </button>
            <button
              onClick={() => setActiveTab('updates')}
              className="flex items-center justify-between rounded-2xl border border-border bg-[#0e0b0d] p-4 text-xs font-mono uppercase tracking-wider hover:border-accent text-left"
            >
              Post a What&apos;s New Update
              <Plus className="size-4 text-accent" />
            </button>
            <button
              onClick={() => setActiveTab('skills')}
              className="flex items-center justify-between rounded-2xl border border-border bg-[#0e0b0d] p-4 text-xs font-mono uppercase tracking-wider hover:border-accent text-left"
            >
              Add New Technical Skill
              <Plus className="size-4 text-accent" />
            </button>
          </div>
        </div>

        <div className="rounded-3xl border border-border bg-card/40 p-7 flex flex-col justify-between">
          <div>
            <h3 className="font-serif text-xl font-light mb-2">Connect messages</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your public portfolio is configured with direct links (GitHub, LinkedIn, and Email) and does not have a contact form, matching your custom request to stay clean and simple.
            </p>
          </div>
          <div className="mt-6 border-t border-border/40 pt-4 text-xs font-mono text-muted-foreground uppercase tracking-widest">
            Inbox Connection: Ready
          </div>
        </div>
      </div>
    </div>
  )
}

// ----------------------------------------------------
// 2. PROFILE & HERO TAB
// ----------------------------------------------------
function ProfileTab({ db, save, uploadImage }: { db: DbSchema; save: any; uploadImage: any }) {
  const [hello, setHello] = useState(db.hero?.hello || '')
  const [name, setName] = useState(db.hero?.name || '')
  const [title, setTitle] = useState(db.hero?.title || '')
  const [bio, setBio] = useState(db.hero?.bio || '')
  const [location, setLocation] = useState(db.hero?.location || '')
  const [creative, setCreative] = useState(db.hero?.creativeTechnologist || '')
  
  // profile card fields
  const [currently, setCurrently] = useState(db.about?.currently || '')
  const [aboutLocation, setAboutLocation] = useState(db.about?.location || '')
  const [focusInput, setFocusInput] = useState(db.about?.focus?.join(', ') || '')

  // Code editor lines
  const [codeLines, setCodeLines] = useState<{ n: number; code: string }[]>(db.hero?.codeLines || [])
  const [codeFilename, setCodeFilename] = useState(db.hero?.codeWindowFilename || 'ikram.js')
  const [codeCaption, setCodeCaption] = useState(db.hero?.codeWindowCaption || 'built with curiosity')

  // Code editor editing helpers
  const handleCodeLineChange = (index: number, val: string) => {
    const lines = [...codeLines]
    lines[index].code = val
    setCodeLines(lines)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    save('profile', {
      hero: {
        hello,
        name,
        title,
        bio,
        location,
        creativeTechnologist: creative,
        codeLines,
        codeWindowFilename: codeFilename,
        codeWindowCaption: codeCaption,
      },
      about: {
        currently,
        location: aboutLocation,
        focus: focusInput.split(',').map(f => f.trim()).filter(Boolean),
        bio: bio // Sync bio for consistency
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Hero section group */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3 flex items-center gap-2">
          <Sparkles className="size-4 text-accent" /> Hero Section Title & Bio
        </h3>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Greeting text</label>
            <input
              type="text"
              value={hello}
              onChange={(e) => setHello(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Name Title</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
            />
          </div>
        </div>

        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Subtitle / Profession Tagline</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif text-lg"
          />
        </div>

        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Introductory Bio</label>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            rows={4}
            className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-4 text-sm focus:border-accent outline-none text-foreground leading-relaxed"
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Location string</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Role/Tagline metadata</label>
            <input
              type="text"
              value={creative}
              onChange={(e) => setCreative(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
        </div>
      </div>

      {/* Code window emulator */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3 flex items-center gap-2">
          <Code className="size-4 text-accent" /> Hero Code Simulator Window
        </h3>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Window tab filename</label>
            <input
              type="text"
              value={codeFilename}
              onChange={(e) => setCodeFilename(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Caption note</label>
            <input
              type="text"
              value={codeCaption}
              onChange={(e) => setCodeCaption(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground italic"
            />
          </div>
        </div>

        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Interactive Code Lines</label>
          <div className="space-y-2 bg-[#0e0b0d] border border-border/60 rounded-2xl p-5">
            {codeLines.map((line, i) => (
              <div key={line.n} className="flex items-center gap-4">
                <span className="font-mono text-xs text-[#5a4750] w-4 text-right">{line.n}</span>
                <input
                  type="text"
                  value={line.code}
                  onChange={(e) => handleCodeLineChange(i, e.target.value)}
                  className="flex-1 bg-transparent border-b border-white/5 outline-none focus:border-accent font-mono text-sm text-[#e6a4c4] py-1"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* About Section details */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3 flex items-center gap-2">
          <User className="size-4 text-accent" /> About Section Card Info
        </h3>

        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Currently doing</label>
          <input
            type="text"
            value={currently}
            onChange={(e) => setCurrently(e.target.value)}
            placeholder="Learning → Building → Experimenting"
            className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Based in City, Country</label>
            <input
              type="text"
              value={aboutLocation}
              onChange={(e) => setAboutLocation(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Focus tags (comma-separated)</label>
            <input
              type="text"
              value={focusInput}
              onChange={(e) => setFocusInput(e.target.value)}
              placeholder="Web, Software, Databases"
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
      >
        Save Profile Configurations
      </button>
    </form>
  )
}

// ----------------------------------------------------
// 3. SKILLS TAB
// ----------------------------------------------------
function SkillsTab({ db, save }: { db: DbSchema; save: any }) {
  const [title, setTitle] = useState(db.skills?.title || '')
  const [description, setDescription] = useState(db.skills?.description || '')
  const [dbTextBadge, setDbTextBadge] = useState(db.skills?.dbTextBadge || '')
  
  // local copy of skills inside groups
  const [groups, setGroups] = useState<SkillGroup[]>(db.skills?.groups || [])
  const [aboutSkills, setAboutSkills] = useState<Skill[]>(db.skills?.aboutSkills || [])

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    save('skills', {
      title,
      description,
      dbTextBadge,
      aboutSkills,
      groups,
    })
  }

  // Edit fields helper
  const updateGroupSkill = (groupIndex: number, skillIndex: number, key: keyof Skill, value: string) => {
    const updated = [...groups]
    updated[groupIndex].skills[skillIndex] = {
      ...updated[groupIndex].skills[skillIndex],
      [key]: value,
    }
    setGroups(updated)
  }

  const deleteGroupSkill = (groupIndex: number, skillIndex: number) => {
    const updated = [...groups]
    updated[groupIndex].skills = updated[groupIndex].skills.filter((_, idx) => idx !== skillIndex)
    setGroups(updated)
  }

  const addGroupSkill = (groupIndex: number) => {
    const updated = [...groups]
    updated[groupIndex].skills.push({
      name: 'NEW SKILL',
      note: 'Skill details',
      icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
    })
    setGroups(updated)
  }

  // Edit main about skills badge list
  const updateAboutSkill = (index: number, key: keyof Skill, value: string) => {
    const updated = [...aboutSkills]
    updated[index] = { ...updated[index], [key]: value }
    setAboutSkills(updated)
  }

  const addAboutSkill = () => {
    setAboutSkills([
      ...aboutSkills,
      { name: 'SKILL', note: 'Hover text', icon: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg' }
    ])
  }

  const deleteAboutSkill = (index: number) => {
    setAboutSkills(aboutSkills.filter((_, i) => i !== index))
  }

  return (
    <form onSubmit={handleSave} className="space-y-8">
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3">Skills Page Text</h3>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Section title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Databases Text Badge</label>
            <input
              type="text"
              value={dbTextBadge}
              onChange={(e) => setDbTextBadge(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
            />
          </div>
        </div>
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Short Description</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
          />
        </div>
      </div>

      {/* Main highlight skills */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <div className="flex items-center justify-between border-b border-border/40 pb-3">
          <h3 className="font-serif text-xl font-light">About section badges (Main highlights)</h3>
          <button
            type="button"
            onClick={addAboutSkill}
            className="flex items-center gap-1.5 rounded-full bg-accent-soft px-3.5 py-1.5 text-[10px] font-mono uppercase tracking-wider text-[#201319]"
          >
            <Plus className="size-3" /> Add Highlight Badge
          </button>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          {aboutSkills.map((skill, index) => (
            <div key={index} className="flex gap-4 p-4 border border-border/60 bg-[#0e0b0d] rounded-2xl relative">
              <button
                type="button"
                onClick={() => deleteAboutSkill(index)}
                className="absolute top-2 right-2 text-muted-foreground hover:text-red-400 p-1"
              >
                <Trash2 className="size-3.5" />
              </button>

              <div className="flex flex-col justify-center gap-1.5 flex-1 pr-6">
                <input
                  type="text"
                  value={skill.name}
                  onChange={(e) => updateAboutSkill(index, 'name', e.target.value)}
                  placeholder="SKILL NAME"
                  className="bg-transparent border-b border-white/5 font-mono text-xs focus:border-accent outline-none"
                />
                <input
                  type="text"
                  value={skill.note}
                  onChange={(e) => updateAboutSkill(index, 'note', e.target.value)}
                  placeholder="Hover details"
                  className="bg-transparent border-b border-white/5 text-xs text-muted-foreground focus:border-accent outline-none"
                />
                <input
                  type="text"
                  value={skill.icon}
                  onChange={(e) => updateAboutSkill(index, 'icon', e.target.value)}
                  placeholder="Icon url"
                  className="bg-transparent border-b border-white/5 text-[10px] text-muted-foreground/60 focus:border-accent outline-none"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Categorized Skills list */}
      <div className="space-y-6">
        {groups.map((group, groupIndex) => (
          <div key={group.num} className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
            <div className="flex items-center justify-between border-b border-border/40 pb-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-accent">{group.num}</span>
                <h4 className="font-serif text-lg">{group.title} Skills</h4>
              </div>

              <button
                type="button"
                onClick={() => addGroupSkill(groupIndex)}
                className="flex items-center gap-1.5 rounded-full bg-accent-soft px-3.5 py-1.5 text-[10px] font-mono uppercase tracking-wider text-[#201319]"
              >
                <Plus className="size-3" /> Add Skill
              </button>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              {group.skills.map((skill, skillIndex) => (
                <div key={skillIndex} className="flex gap-4 p-4 border border-border/60 bg-[#0e0b0d] rounded-2xl relative">
                  <button
                    type="button"
                    onClick={() => deleteGroupSkill(groupIndex, skillIndex)}
                    className="absolute top-2 right-2 text-muted-foreground hover:text-red-400 p-1"
                  >
                    <Trash2 className="size-3.5" />
                  </button>

                  <div className="flex flex-col justify-center gap-1.5 flex-1 pr-6">
                    <input
                      type="text"
                      value={skill.name}
                      onChange={(e) => updateGroupSkill(groupIndex, skillIndex, 'name', e.target.value)}
                      placeholder="SKILL NAME"
                      className="bg-transparent border-b border-white/5 font-mono text-xs focus:border-accent outline-none"
                    />
                    <input
                      type="text"
                      value={skill.note}
                      onChange={(e) => updateGroupSkill(groupIndex, skillIndex, 'note', e.target.value)}
                      placeholder="Hover details"
                      className="bg-transparent border-b border-white/5 text-xs text-muted-foreground focus:border-accent outline-none"
                    />
                    <input
                      type="text"
                      value={skill.icon}
                      onChange={(e) => updateGroupSkill(groupIndex, skillIndex, 'icon', e.target.value)}
                      placeholder="Icon url"
                      className="bg-transparent border-b border-white/5 text-[10px] text-muted-foreground/60 focus:border-accent outline-none"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <button
        type="submit"
        className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
      >
        Save Skills Configuration
      </button>
    </form>
  )
}

// ----------------------------------------------------
// 4. JOURNEY STAGES TAB
// ----------------------------------------------------
function JourneyTab({ db, save }: { db: DbSchema; save: any }) {
  const [title, setTitle] = useState(db.journey?.title || '')
  const [ctaTitle, setCtaTitle] = useState(db.journey?.ctaTitle || '')
  const [ctaButtonText, setCtaButtonText] = useState(db.journey?.ctaButtonText || '')
  const [stages, setStages] = useState<JourneyStage[]>(db.journey?.stages || [])

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    save('journey', {
      title,
      stages,
      ctaTitle,
      ctaButtonText,
    })
  }

  // CRUD helpers
  const handleStageChange = (index: number, key: keyof JourneyStage, val: any) => {
    const updated = [...stages]
    updated[index] = { ...updated[index], [key]: val }
    setStages(updated)
  }

  const deleteStage = (index: number) => {
    const updated = stages.filter((_, i) => i !== index)
    // Normalize step numbers e.g. "01", "02"...
    const normalized = updated.map((s, i) => ({
      ...s,
      num: String(i + 1).padStart(2, '0'),
      stage: `STAGE ${String(i + 1).padStart(2, '0')}`
    }))
    setStages(normalized)
  }

  const addStage = () => {
    const num = String(stages.length + 1).padStart(2, '0')
    const newStage: JourneyStage = {
      num,
      short: 'Timeline Node',
      stage: `STAGE ${num}`,
      title: 'Timeline stage title',
      body: ' timeline node details...',
      tags: ['Topic', 'Focus']
    }
    setStages([...stages, newStage])
  }

  // Reordering helpers
  const moveStage = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return
    if (direction === 'down' && index === stages.length - 1) return

    const newIndex = direction === 'up' ? index - 1 : index + 1
    const updated = [...stages]
    
    // Swap items
    const temp = updated[index]
    updated[index] = updated[newIndex]
    updated[newIndex] = temp

    // Re-normalize indices & stage indicators
    const normalized = updated.map((s, i) => ({
      ...s,
      num: String(i + 1).padStart(2, '0'),
      stage: `STAGE ${String(i + 1).padStart(2, '0')}`
    }))

    setStages(normalized)
  }

  return (
    <form onSubmit={handleSave} className="space-y-8">
      {/* Journey Settings */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
        <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3">Journey Section Text</h3>
        <div>
          <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Section title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
          />
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">CTA banner title</label>
            <input
              type="text"
              value={ctaTitle}
              onChange={(e) => setCtaTitle(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
            />
          </div>
          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">CTA button text</label>
            <input
              type="text"
              value={ctaButtonText}
              onChange={(e) => setCtaButtonText(e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>
        </div>
      </div>

      {/* Stepper list */}
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-6">
        <div className="flex items-center justify-between border-b border-border/40 pb-3">
          <h3 className="font-serif text-xl font-light">Journey Stages / Timeline</h3>
          <button
            type="button"
            onClick={addStage}
            className="flex items-center gap-1.5 rounded-full bg-accent-soft px-3.5 py-1.5 text-[10px] font-mono uppercase tracking-wider text-[#201319]"
          >
            <Plus className="size-3" /> Add Stage
          </button>
        </div>

        <div className="space-y-6">
          {stages.map((s, index) => (
            <div key={index} className="border border-border/60 bg-[#0e0b0d] rounded-2xl p-5 relative space-y-4">
              <div className="flex items-center justify-between border-b border-border/20 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-accent">{s.num}</span>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                    {s.stage}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => moveStage(index, 'up')}
                    disabled={index === 0}
                    className="text-muted-foreground hover:text-accent p-1.5 border border-border/30 rounded-lg disabled:opacity-30"
                  >
                    <ArrowUp className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => moveStage(index, 'down')}
                    disabled={index === stages.length - 1}
                    className="text-muted-foreground hover:text-accent p-1.5 border border-border/30 rounded-lg disabled:opacity-30"
                  >
                    <ArrowDown className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteStage(index)}
                    className="text-muted-foreground hover:text-red-400 p-1.5 border border-border/30 rounded-lg"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block font-mono text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Stepper Label</label>
                  <input
                    type="text"
                    value={s.short}
                    onChange={(e) => handleStageChange(index, 'short', e.target.value)}
                    className="w-full bg-[#141013] border border-border/60 rounded-xl p-2.5 text-xs text-foreground font-serif"
                  />
                </div>
                <div>
                  <label className="block font-mono text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Card Header Title</label>
                  <input
                    type="text"
                    value={s.title}
                    onChange={(e) => handleStageChange(index, 'title', e.target.value)}
                    className="w-full bg-[#141013] border border-border/60 rounded-xl p-2.5 text-xs text-foreground font-serif"
                  />
                </div>
              </div>

              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Body Text</label>
                <textarea
                  value={s.body}
                  onChange={(e) => handleStageChange(index, 'body', e.target.value)}
                  rows={2}
                  className="w-full bg-[#141013] border border-border/60 rounded-xl p-3 text-xs text-foreground leading-relaxed"
                />
              </div>

              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-muted-foreground mb-1">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={s.tags?.join(', ') || ''}
                  onChange={(e) => handleStageChange(index, 'tags', e.target.value.split(',').map(t => t.trim()).filter(Boolean))}
                  placeholder="e.g. Relational Databases, MySQL"
                  className="w-full bg-[#141013] border border-border/60 rounded-xl p-2.5 text-xs text-foreground"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <button
        type="submit"
        className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
      >
        Save Journey Changes
      </button>
    </form>
  )
}

// ----------------------------------------------------
// 5. CERTIFICATIONS TAB (CRUD & REORDER & UPLOADS)
// ----------------------------------------------------
interface CertFormState {
  id?: string
  name: string
  organization: string
  date: string
  credentialId: string
  credentialUrl: string
  image: string
  description: string
  visible: boolean
}

function CertificationsTab({ db, save, uploadImage }: { db: DbSchema; save: any; uploadImage: any }) {
  const [certs, setCerts] = useState<Certification[]>(db.certifications || [])
  const [isEditing, setIsEditing] = useState(false)
  const [editForm, setEditForm] = useState<CertFormState>({
    name: '',
    organization: '',
    date: '',
    credentialId: '',
    credentialUrl: '',
    image: '',
    description: '',
    visible: true
  })
  
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleEditClick = (cert: Certification) => {
    setEditForm({
      id: cert.id,
      name: cert.name,
      organization: cert.organization,
      date: cert.date,
      credentialId: cert.credentialId || '',
      credentialUrl: cert.credentialUrl || '',
      image: cert.image || '',
      description: cert.description || '',
      visible: cert.visible !== false
    })
    setIsEditing(true)
  }

  const handleAddClick = () => {
    setEditForm({
      name: '',
      organization: '',
      date: '',
      credentialId: '',
      credentialUrl: '',
      image: '',
      description: '',
      visible: true
    })
    setIsEditing(true)
  }

  // Handle Form Input Changes
  const handleInputChange = (key: keyof CertFormState, val: any) => {
    setEditForm({ ...editForm, [key]: val })
  }

  // Handle image upload from form
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      const path = await uploadImage(file)
      handleInputChange('image', path)
    } catch (err) {
      alert('Failed to upload image')
    }
  }

  // Save/Create operation
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const url = '/api/admin/certifications'
    const method = editForm.id ? 'PUT' : 'POST'
    
    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      })
      
      if (res.ok) {
        const json = await res.json()
        setCerts(json.certifications || [])
        setIsEditing(false)
      } else {
        alert('Failed to save certification')
      }
    } catch (err) {
      console.error(err)
    }
  }

  // Delete operation
  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this certification?')) return

    try {
      const res = await fetch(`/api/admin/certifications?id=${id}`, {
        method: 'DELETE',
      })
      if (res.ok) {
        const json = await res.json()
        setCerts(json.certifications || [])
      } else {
        alert('Failed to delete')
      }
    } catch (err) {
      console.error(err)
    }
  }

  // Reorder operation (Up/Down)
  const moveCert = async (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return
    if (direction === 'down' && index === certs.length - 1) return

    const newIndex = direction === 'up' ? index - 1 : index + 1
    const updated = [...certs]
    const temp = updated[index]
    updated[index] = updated[newIndex]
    updated[newIndex] = temp

    // Send array to bulk reorder PUT endpoint
    try {
      const res = await fetch('/api/admin/certifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      })
      if (res.ok) {
        const json = await res.json()
        setCerts(json.certifications || [])
      }
    } catch (err) {
      console.error(err)
    }
  }

  // Toggle Visibility
  const toggleVisibility = async (cert: Certification) => {
    try {
      const res = await fetch('/api/admin/certifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...cert, visible: !cert.visible }),
      })
      if (res.ok) {
        const json = await res.json()
        setCerts(json.certifications || [])
      }
    } catch (err) {
      console.error(err)
    }
  }

  // Render Form view
  if (isEditing) {
    return (
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-6">
        <div className="flex items-center justify-between border-b border-border/40 pb-3">
          <h3 className="font-serif text-xl font-light">
            {editForm.id ? 'Edit Certification' : 'Add Certification'}
          </h3>
          <button
            type="button"
            onClick={() => setIsEditing(false)}
            className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:text-foreground"
          >
            Cancel
          </button>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Certification Name</label>
              <input
                type="text"
                required
                value={editForm.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
              />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Issuing Organization</label>
              <input
                type="text"
                required
                value={editForm.organization}
                onChange={(e) => handleInputChange('organization', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
              />
            </div>
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Issue Date (e.g. Month Year)</label>
              <input
                type="text"
                required
                value={editForm.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                placeholder="August 2026"
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
              />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Credential ID (Optional)</label>
              <input
                type="text"
                value={editForm.credentialId}
                onChange={(e) => handleInputChange('credentialId', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Credential Verification URL (Optional)</label>
            <input
              type="url"
              value={editForm.credentialUrl}
              onChange={(e) => handleInputChange('credentialUrl', e.target.value)}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-[1fr_120px] items-end">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Logo/Certificate Badge Image Path</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={editForm.image}
                  onChange={(e) => handleInputChange('image', e.target.value)}
                  placeholder="/uploads/file.png"
                  className="flex-1 rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-2xl border border-border bg-card p-3 text-muted-foreground hover:text-accent"
                >
                  <Upload className="size-4" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            </div>
            {editForm.image && (
              <div className="size-16 rounded-xl border border-border bg-[#0e0b0d] flex items-center justify-center p-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={editForm.image} alt="" className="size-full object-contain" />
              </div>
            )}
          </div>

          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Short Description (Optional)</label>
            <textarea
              value={editForm.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              rows={3}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-4 text-sm focus:border-accent outline-none text-foreground leading-relaxed"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => handleInputChange('visible', !editForm.visible)}
              className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
            >
              {editForm.visible ? (
                <>
                  <Eye className="size-4 text-green-400" /> Publicly Published
                </>
              ) : (
                <>
                  <EyeOff className="size-4 text-yellow-500" /> Private Draft
                </>
              )}
            </button>
          </div>

          <button
            type="submit"
            className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
          >
            Save Certification
          </button>
        </form>
      </div>
    )
  }

  // Render List view
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-serif text-xl font-light">My Credentials ({certs.length})</h3>
        <button
          onClick={handleAddClick}
          className="flex items-center gap-1.5 rounded-full bg-accent-soft px-4 py-2 text-xs font-mono uppercase tracking-wider text-[#201319]"
        >
          <Plus className="size-4" /> Add Certification
        </button>
      </div>

      {certs.length === 0 ? (
        <div className="rounded-3xl border border-border bg-card/10 p-10 text-center text-sm text-muted-foreground">
          No certifications added yet. Click &quot;Add Certification&quot; to begin.
        </div>
      ) : (
        <div className="space-y-4">
          {certs.map((c, index) => (
            <div
              key={c.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl border border-border bg-[#0e0b0d] p-6"
            >
              <div className="flex items-center gap-4">
                {c.image ? (
                  <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-white to-[#ffeaf3] p-2.5 shrink-0">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={c.image} alt="" className="size-full object-contain" />
                  </div>
                ) : (
                  <div className="flex size-14 items-center justify-center rounded-2xl border border-border bg-card text-accent shrink-0">
                    <Award className="size-6" />
                  </div>
                )}

                <div>
                  <h4 className="font-serif text-lg font-medium leading-tight">{c.name}</h4>
                  <p className="text-xs text-muted-foreground font-serif italic mt-0.5">{c.organization}</p>
                  <div className="flex items-center gap-2 mt-1.5 font-mono text-[9px] text-muted-foreground/80 uppercase tracking-widest">
                    <span>Issued: {c.date}</span>
                    {c.credentialId && (
                      <>
                        <span>·</span>
                        <span className="max-w-[120px] truncate">ID: {c.credentialId}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 border-t border-border/20 pt-4 sm:pt-0 sm:border-t-0 justify-end">
                <button
                  onClick={() => toggleVisibility(c)}
                  className={`p-2 border border-border/60 rounded-xl transition-colors ${
                    c.visible !== false ? 'text-green-400 hover:bg-green-950/20' : 'text-yellow-500 hover:bg-yellow-950/20'
                  }`}
                  title={c.visible !== false ? 'Make Draft' : 'Publish'}
                >
                  {c.visible !== false ? <Eye className="size-3.5" /> : <EyeOff className="size-3.5" />}
                </button>
                <button
                  onClick={() => moveCert(index, 'up')}
                  disabled={index === 0}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-accent transition-colors disabled:opacity-30"
                >
                  <ArrowUp className="size-3.5" />
                </button>
                <button
                  onClick={() => moveCert(index, 'down')}
                  disabled={index === certs.length - 1}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-accent transition-colors disabled:opacity-30"
                >
                  <ArrowDown className="size-3.5" />
                </button>
                <button
                  onClick={() => handleEditClick(c)}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-accent transition-colors"
                >
                  <Edit className="size-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(c.id)}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-red-400 transition-colors"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ----------------------------------------------------
// 6. SOCIAL LINKS TAB
// ----------------------------------------------------
function SocialsTab({ db, save }: { db: DbSchema; save: any }) {
  const [github, setGithub] = useState(db.socials?.github || '')
  const [linkedin, setLinkedin] = useState(db.socials?.linkedin || '')
  const [email, setEmail] = useState(db.socials?.email || '')
  const [fiverr, setFiverr] = useState(db.socials?.fiverr || '')

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    save('profile', {
      socials: { github, linkedin, email, fiverr }
    })
  }

  return (
    <form onSubmit={handleSave} className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
      <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3">Website Social Channels</h3>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">GitHub URL</label>
        <input
          type="url"
          value={github}
          onChange={(e) => setGithub(e.target.value)}
          placeholder="https://github.com/..."
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">LinkedIn URL</label>
        <input
          type="url"
          value={linkedin}
          onChange={(e) => setLinkedin(e.target.value)}
          placeholder="https://linkedin.com/in/..."
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Email Address</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="email@example.com"
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Fiverr URL (Optional)</label>
        <input
          type="url"
          value={fiverr}
          onChange={(e) => setFiverr(e.target.value)}
          placeholder="https://fiverr.com/..."
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
        />
      </div>

      <button
        type="submit"
        className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
      >
        Save Social Channels
      </button>
    </form>
  )
}

// ----------------------------------------------------
// 7. UPDATES / WHAT'S NEW TAB
// ----------------------------------------------------
interface UpdateFormState {
  id?: string
  title: string
  description: string
  date: string
  image: string
  visible: boolean
  category: 'certification' | 'skill' | 'achievement' | 'experience' | 'update'
}

function UpdatesTab({ db, save, uploadImage }: { db: DbSchema; save: any; uploadImage: any }) {
  const [updates, setUpdates] = useState<PortfolioUpdate[]>(db.updates || [])
  const [isEditing, setIsEditing] = useState(false)
  const [editForm, setEditForm] = useState<UpdateFormState>({
    title: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
    image: '',
    visible: true,
    category: 'update'
  })
  
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleEditClick = (upd: PortfolioUpdate) => {
    setEditForm({
      id: upd.id,
      title: upd.title,
      description: upd.description,
      date: upd.date,
      image: upd.image || '',
      visible: upd.visible !== false,
      category: upd.category || 'update'
    })
    setIsEditing(true)
  }

  const handleAddClick = () => {
    setEditForm({
      title: '',
      description: '',
      date: new Date().toISOString().split('T')[0],
      image: '',
      visible: true,
      category: 'update'
    })
    setIsEditing(true)
  }

  const handleInputChange = (key: keyof UpdateFormState, val: any) => {
    setEditForm({ ...editForm, [key]: val })
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      const path = await uploadImage(file)
      handleInputChange('image', path)
    } catch (err) {
      alert('Upload failed')
    }
  }

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const url = '/api/admin/updates'
    const method = editForm.id ? 'PUT' : 'POST'
    
    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      })
      if (res.ok) {
        const json = await res.json()
        setUpdates(json.updates || [])
        setIsEditing(false)
      } else {
        alert('Save error')
      }
    } catch (err) {
      console.error(err)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Permanently delete this update log?')) return
    try {
      const res = await fetch(`/api/admin/updates?id=${id}`, { method: 'DELETE' })
      if (res.ok) {
        const json = await res.json()
        setUpdates(json.updates || [])
      }
    } catch (err) {
      console.error(err)
    }
  }

  const toggleVisibility = async (upd: PortfolioUpdate) => {
    try {
      const res = await fetch('/api/admin/updates', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...upd, visible: !upd.visible }),
      })
      if (res.ok) {
        const json = await res.json()
        setUpdates(json.updates || [])
      }
    } catch (err) {
      console.error(err)
    }
  }

  if (isEditing) {
    return (
      <div className="rounded-3xl border border-border bg-card/40 p-7 space-y-6">
        <div className="flex items-center justify-between border-b border-border/40 pb-3">
          <h3 className="font-serif text-xl font-light">
            {editForm.id ? 'Edit Update Log' : 'Post New Update'}
          </h3>
          <button type="button" onClick={() => setIsEditing(false)} className="font-mono text-[10px] text-muted-foreground">
            Cancel
          </button>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-[1fr_200px]">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Update Title</label>
              <input
                type="text"
                required
                value={editForm.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
              />
            </div>
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Update Category</label>
              <select
                value={editForm.category}
                onChange={(e) => handleInputChange('category', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
              >
                <option value="update">Update</option>
                <option value="certification">Certification</option>
                <option value="skill">Skill</option>
                <option value="achievement">Achievement</option>
                <option value="experience">Experience</option>
              </select>
            </div>
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Date (YYYY-MM-DD)</label>
              <input
                type="date"
                required
                value={editForm.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
              />
            </div>

            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Optional Image (Upload or path)</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={editForm.image}
                  onChange={(e) => handleInputChange('image', e.target.value)}
                  className="flex-1 rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="rounded-2xl border border-border bg-card p-3 text-muted-foreground hover:text-accent"
                >
                  <Upload className="size-4" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Description Detail</label>
            <textarea
              required
              value={editForm.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              rows={4}
              className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-4 text-sm focus:border-accent outline-none text-foreground leading-relaxed"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => handleInputChange('visible', !editForm.visible)}
              className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
            >
              {editForm.visible ? (
                <>
                  <Eye className="size-4 text-green-400" /> Publicly Published
                </>
              ) : (
                <>
                  <EyeOff className="size-4 text-yellow-500" /> Private Draft
                </>
              )}
            </button>
          </div>

          <button
            type="submit"
            className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
          >
            Publish Update
          </button>
        </form>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-serif text-xl font-light">Updates Log ({updates.length})</h3>
        <button
          onClick={handleAddClick}
          className="flex items-center gap-1.5 rounded-full bg-accent-soft px-4 py-2 text-xs font-mono uppercase tracking-wider text-[#201319]"
        >
          <Plus className="size-4" /> Add Update
        </button>
      </div>

      {updates.length === 0 ? (
        <div className="rounded-3xl border border-border bg-card/10 p-10 text-center text-sm text-muted-foreground">
          No updates posted yet.
        </div>
      ) : (
        <div className="space-y-4">
          {updates.map((u) => (
            <div
              key={u.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-3xl border border-border bg-[#0e0b0d] p-6"
            >
              <div>
                <h4 className="font-serif text-lg font-medium leading-tight">{u.title}</h4>
                <p className="text-xs text-muted-foreground/80 font-mono uppercase tracking-widest mt-1">
                  {u.date} · <span className="text-accent">{u.category}</span>
                </p>
                <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{u.description}</p>
              </div>

              <div className="flex items-center gap-2 border-t border-border/20 pt-4 sm:pt-0 sm:border-t-0 justify-end">
                <button
                  onClick={() => toggleVisibility(u)}
                  className={`p-2 border border-border/60 rounded-xl transition-colors ${
                    u.visible !== false ? 'text-green-400 hover:bg-green-950/20' : 'text-yellow-500 hover:bg-yellow-950/20'
                  }`}
                >
                  {u.visible !== false ? <Eye className="size-3.5" /> : <EyeOff className="size-3.5" />}
                </button>
                <button
                  onClick={() => handleEditClick(u)}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-accent transition-colors"
                >
                  <Edit className="size-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(u.id)}
                  className="p-2 border border-border/60 rounded-xl text-muted-foreground hover:text-red-400 transition-colors"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ----------------------------------------------------
// 8. SITE SETTINGS TAB
// ----------------------------------------------------
function SettingsTab({ db, save }: { db: DbSchema; save: any }) {
  const [metaTitle, setMetaTitle] = useState(db.siteSettings?.metaTitle || '')
  const [metaDescription, setMetaDescription] = useState(db.siteSettings?.metaDescription || '')
  const [wordmark, setWordmark] = useState(db.siteSettings?.wordmark || '')
  const [copyright, setCopyright] = useState(db.siteSettings?.copyright || '')

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    save('profile', {
      siteSettings: {
        metaTitle,
        metaDescription,
        wordmark,
        copyright
      }
    })
  }

  return (
    <form onSubmit={handleSave} className="rounded-3xl border border-border bg-card/40 p-7 space-y-5">
      <h3 className="font-serif text-xl font-light border-b border-border/40 pb-3">Global SEO & settings</h3>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Wordmark Logo Text</label>
        <input
          type="text"
          value={wordmark}
          onChange={(e) => setWordmark(e.target.value)}
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-serif"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">Copyright label</label>
        <input
          type="text"
          value={copyright}
          onChange={(e) => setCopyright(e.target.value)}
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground font-mono"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">SEO Meta Title</label>
        <input
          type="text"
          value={metaTitle}
          onChange={(e) => setMetaTitle(e.target.value)}
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-3 text-sm focus:border-accent outline-none text-foreground"
        />
      </div>

      <div>
        <label className="block font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-2">SEO Meta Description</label>
        <textarea
          value={metaDescription}
          onChange={(e) => setMetaDescription(e.target.value)}
          rows={3}
          className="w-full rounded-2xl border border-border bg-[#0e0b0d] p-4 text-sm focus:border-accent outline-none text-foreground leading-relaxed"
        />
      </div>

      <button
        type="submit"
        className="rounded-full bg-accent-soft px-8 py-3.5 text-xs font-mono uppercase tracking-wider text-[#201319] hover:bg-accent transition-transform hover:-translate-y-0.5"
      >
        Save Site Settings
      </button>
    </form>
  )
}

